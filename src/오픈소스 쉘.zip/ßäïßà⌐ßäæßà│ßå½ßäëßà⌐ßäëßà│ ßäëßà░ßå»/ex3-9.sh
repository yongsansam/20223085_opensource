#!/bin/sh
fname=jmevif/DB.txt

grep $1 $fname

exit 0
