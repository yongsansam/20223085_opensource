#!/bin/bash
read var
for ((i=0; i<var;i++))
do
	echo "hello world"
done
