#!/bin/bash
read num1 cal num2
case $cal in
	'+') output=`expr $num1 + $num2`;;
	'=') output=`expr $num1 - $num2`;;
esac
echo $output

