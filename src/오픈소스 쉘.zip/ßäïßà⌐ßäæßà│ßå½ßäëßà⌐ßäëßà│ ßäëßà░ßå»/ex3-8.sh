#!/bin/sh
jmevif/DB.txt

touch DB.txt

echo "$1" "$2" >> DB.txt

exit 0
